package com.java.container;

public class ChemicalElement implements Comparable<ChemicalElement>
{
private int atomicNumber;
private String atomicName;
private String atomiFormula;
private double atomicWeight;
public ChemicalElement(int atomicNumber, String atomicName, String atomiFormula, double atomicWeight) {
super();
this.atomicNumber = atomicNumber;
this.atomicName = atomicName;
this.atomiFormula = atomiFormula;
this.atomicWeight = atomicWeight;
}
@Override
public String toString() {
return "ChemicalElement [atomicNumber=" + atomicNumber + ", atomicName=" + atomicName + ", atomiFormula="
+ atomiFormula + ", atomicWeight=" + atomicWeight + "]";
}
/*
@Override
public int compareTo(ChemicalElement o) {
System.out.println("comparing"+" "+atomicNumber+" "+"with"+""+o.atomicNumber);
return Integer.compare(atomicNumber, o.atomicNumber);
}
*/
@Override
public int compareTo(ChemicalElement o) {
System.out.println("comparing"+" "+atomiFormula+" "+"with"+""+o.atomiFormula);
return atomiFormula.compareTo(o.atomiFormula);
}}