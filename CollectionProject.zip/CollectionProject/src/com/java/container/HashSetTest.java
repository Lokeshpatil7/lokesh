package com.java.container;

import java.util.HashSet;

public class HashSetTest {
	public static void main(String[] args) {
	
		Books bookObj1 = new Books(101,"JPL","James Gosling",900,1200,4);
		
		System.out.println("bookObj1 "+bookObj1.hashCode());
		
		Books bookObj2 = new Books(101,"JPL11","James Gosling",900,1200,4);
		System.out.println("bookObj2 "+bookObj2.hashCode());
		
		Books bookObj3 = bookObj1;
		
		Books bookObj4 = bookObj2;
		
		System.out.println("bookObj3 "+bookObj3.hashCode());
		System.out.println("bookObj4 "+bookObj4.hashCode());
	
		Books bookObj5 = new Books(101,"JPL","James Bhosle",900,1200,4);
		System.out.println("bookObj5 "+bookObj5.hashCode());
	
		
		Books bookObj6 = new Books(101,"JPL","James Gosling",1900,1200,4);
		System.out.println("bookObj6 "+bookObj6.hashCode());
	
		Books bookObj7 = new Books(101,"JPL","James Gosling",1900,1500,4);
		System.out.println("bookObj7 "+bookObj7.hashCode());
	

		Books bookObj8 = new Books(101,"JPL","James Gosling",1900,1500,5);
		System.out.println("bookObj8 "+bookObj8.hashCode());
	
		
		HashSet<Books> bookShelf = new HashSet<Books>();
		
		bookShelf.add(bookObj1);
		
		bookShelf.add(bookObj2);
		bookShelf.add(bookObj3);
		bookShelf.add(bookObj4);
		bookShelf.add(bookObj5);
		bookShelf.add(bookObj6);
		bookShelf.add(bookObj7);
		bookShelf.add(bookObj8);
		
		for( Books theBook   : bookShelf  ) {
			System.out.println("the book is : "+theBook);
		}

	}
}