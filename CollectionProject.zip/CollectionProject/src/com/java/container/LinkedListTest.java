package com.java.container;

import java.util.LinkedList;
import java.util.List;

public class LinkedListTest {

	public static void main(String[] args) { 
		// TODO Auto-generated method stub
		
		 List<Book> list=new LinkedList<Book>();      //Create list of Books  
		 
		
		    Book b1=new Book(1001,"agnipankh","A. P. J. Abdul Kalam","Rajhans Prakashan",10);   //Creating Books  
		    Book b2=new Book(1002,"Wings of Fire & Networking","Arun Tiwari","Universities Press",4);   //Creating Books  
		    Book b3=new Book(1003,"believe in yourself","Joseph Murphy","Simon & Schuster",6);   //Creating Books  
		    
		
		    list.add(b1);    //Add Book  to list  
		    list.add(b2);  //Add Book  to list  
		    list.add(b3);  //Add Book  to list  
		    
		    
		   
		    for(Book b:list){  
		    System.out.println(b.id+" "+b.name+" "+b.author+" "+b.publisher+" "+b.quantity);  
		    }   

	}

}
