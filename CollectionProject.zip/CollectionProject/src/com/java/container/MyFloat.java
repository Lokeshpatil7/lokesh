package com.java.container;

public class MyFloat
{
	private float x;
	private float y;
	
	public MyFloat(float x, float y) {
		super();
		this.x = x;
		this.y = y;
	}
	public void swap() {
		System.out.println("Swapping...");
		float temp =x; x =y; x=temp;
	}
	public void print() {
		System.out.println("x ="+x);
		System.out.println("y ="+y);
	}	
}
