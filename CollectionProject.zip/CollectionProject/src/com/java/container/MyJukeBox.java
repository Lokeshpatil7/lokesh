package com.java.container;

public class MyJukeBox {
	private Song x; 
	private Song y;
	public MyJukeBox(Song x, Song y) {
		super();
		this.x = x;
		this.y = y;
	}
	public void swap() {
		System.out.println("Swapping...");
		Song temp =x; x=y;  y=temp;		
	}
	public void print() {
		System.out.println("x "+x);
		System.out.println("y "+y);
	}
}


