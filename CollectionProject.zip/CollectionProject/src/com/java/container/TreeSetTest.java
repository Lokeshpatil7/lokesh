package com.java.container;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetTest 
{


public static void main(String[] args)
{
ChemicalElement chemicalElement=new ChemicalElement(10, "Neova", "Aluminium", 11.9);
ChemicalElement chemicalElement2=new ChemicalElement(8, "Neova", "Phospherous",44.7);
ChemicalElement chemicalElement3=new ChemicalElement(66, "Neova", "Floron", 44.8);
ChemicalElement chemicalElement4=new ChemicalElement(33, "Neova", "Clorin", 88.8);
ChemicalElement chemicalElement5=new ChemicalElement(55, "Neova", "Oxy", 44.7);

 TreeSet<ChemicalElement> PeriodicTable = new TreeSet<ChemicalElement>();
 System.out.println("Container is ready....");
 PeriodicTable.add(chemicalElement);
 PeriodicTable.add(chemicalElement2);
 PeriodicTable.add(chemicalElement3);
 PeriodicTable.add(chemicalElement4);
 PeriodicTable.add(chemicalElement5);
 
 
System.out.println("Added all the elements.....");

System.out.println("Content is added to the container.....");
Iterator<ChemicalElement> periodicTablelist = PeriodicTable.iterator();
while(periodicTablelist.hasNext())
{

System.out.println(periodicTablelist.next());
}

  }

}

