package com.example.demo.layer3;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.example.demo.layer2.Admin;


@Repository
public interface AdminRepository 
{
	    void insertAdmin(Admin Aobj);
	  
	    Admin selectAdmin(String username); //R
		List<Admin> selectAdmin(); //RA
		
		void updateAdmin(Admin Aobj); //U
		void deleteAdmin(String username); //D
}
