package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Admin;
@Repository
public class AdminRepositoryImpl extends BaseRepository implements AdminRepository
{
	public AdminRepositoryImpl() {
		System.out.println("AdminRepoImpl ..");	
		
}

	@Override
	public void insertAdmin(Admin Aobj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Admin selectAdmin(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Admin> selectAdmin() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateAdmin(Admin Aobj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAdmin(String username) {
		// TODO Auto-generated method stub
		
	}

//	@Override
//	public Admin getValidation(String username, String password) {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
