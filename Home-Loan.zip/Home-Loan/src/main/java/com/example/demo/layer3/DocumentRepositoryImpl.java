package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Document;

@Repository
public class DocumentRepositoryImpl extends BaseRepository implements DocumentRepository {

	@Transactional
	public void insertDocument(Document Dobj) {
		super.persist(Dobj);
		System.out.println("Document Inserted");

	}

	@Override
	public Document selectDocument(int docId) {
		System.out.println("DocumentRepositoryImpl : selecting Document  by docId");
// Customer cus = super.find(Customer.class, cust_id);
		Document document = super.find(Document.class, docId);
		System.out.println("repo : cus " + document);
// System.out.println("cus "+cus.getCust_Id());
// System.out.println("cus "+cus.getFirstName());
// System.out.println("cus "+cus.getMiddleName());
// System.out.println("cus "+cus.getLastName());
// System.out.println("cus "+cus.getAdhaarNo());
// System.out.println("cus "+cus.getEmail());
// System.out.println("cus"+cus.getNationality());
// System.out.println("cus "+cus.getPanCard());
//
//

		return document;
	}

	@Override
	public List<Document> selectDocuments() {
		List<Document> doctList = new ArrayList<Document>();

		System.out.println("DocumentRepositoryImpl : Selecting all documents...");
		doctList = super.findAll("Document");
		System.out.println("repo : doctList ref  " + doctList);
		System.out.println("repo : doctList size " + doctList.size());

		for (Document doc : doctList) {
//System.out.println("repo: dept "+dept.getDepartmentNumber());
// System.out.println("cus"+cus.getCust_Id());
// System.out.println("cus "+cus.getFirstName());
// System.out.println("cus "+cus.getMiddleName());
// System.out.println("cus "+cus.getLastName());
// System.out.println("cus "+cus.getAdhaarNo());
// System.out.println("cus "+cus.getEmail());
// System.out.println("cus "+cus.getNationality());
// System.out.println("cus "+cus.getPanCard());
//

		}
		return doctList;
	}

	@Transactional
	public void updateDoument(Document Dobj) {
		System.out.println("DocumentRepositoryImpl : update Document by Dobj");
		super.merge(Dobj);

	}

	@Transactional
	public void deleteDocument(int docId) {
		System.out.println("DocumentRepositoryImpl :Deleted by Document");
		super.remove(Document.class, docId);

	}

}
