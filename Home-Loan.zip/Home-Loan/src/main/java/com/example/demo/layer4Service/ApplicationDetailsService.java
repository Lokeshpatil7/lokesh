package com.example.demo.layer4Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Application_Details;



@Service
public interface ApplicationDetailsService {
	List<Application_Details> getAllApplicationDetailsService();
	List<Application_Details> getAllApplicationDetailsFromDatabaseService();
	void addApplicationDetailsService(Application_Details theApplicationDetails);
}
