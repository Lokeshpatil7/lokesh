package com.example.demo.layer4Service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.example.demo.layer2.Bank;

@Service
public interface BankService {
	List<Bank> getAllBankService();
	List<Bank> getAllBanksFromDatabaseService();
	void addBankService(Bank theBank);
}
