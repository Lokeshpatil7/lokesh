package com.example.demo.layer5Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Bank;
import com.example.demo.layer2.Customer;
import com.example.demo.layer3.BankRepositoryImpl;

@RestController
@RequestMapping("/bank")
public class BankController {

	@Autowired
	BankRepositoryImpl bankRepo;
	
	@GetMapping("/getbank/{b_id}")//localhost:8080/bank/getbank/50
	public Bank getBank(@PathVariable("b_id") int x)
	{
		Bank bank = null;
		bank=bankRepo.selectBank(x);
		
		System.out.println("controller : loan : "+bank.getB_Id());
		return bank;
	}
	@RequestMapping("/getAll")//localhost:8080/bank/getAll
	public List<Bank> getbanks()
	{
		System.out.println("getAll");
		List<Bank> bankList;
		bankList=bankRepo.selectBanks();
		return bankList;
	}
	
	@PostMapping("/Add")
	public void addBanks(@RequestBody Bank bank)
	{
		bankRepo.insertBank(bank);
	}
	
	@PutMapping("/update")//http://localhost:8080/bank/update
	public void updateBank(@RequestBody Bank bank)
	{
		bankRepo.updateBank(bank);
	}
	
	@DeleteMapping("/delete/{b_id}")//http://localhost:8080/bank/delete/45
	 public String deleteBank(@PathVariable("b_id") int b_id)
	 {
		bankRepo.deleteBank(b_id);
	 return "delete successfully";
	 }
	
}