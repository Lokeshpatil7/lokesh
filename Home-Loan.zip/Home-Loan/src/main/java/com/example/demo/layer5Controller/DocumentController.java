package com.example.demo.layer5Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Document;
import com.example.demo.layer2.Loan;
import com.example.demo.layer3.DocumentRepositoryImpl;
import com.example.demo.layer3.LoanRepositoryImpl;

@RestController
@RequestMapping("/document")
public class DocumentController {

	@Autowired
	DocumentRepositoryImpl docRepo;

	@GetMapping("/getdocument/{docId}") // localhost:8080/document/getdocument/73
	public Document getDocument(@PathVariable("docId") int x) {
		Document document = null;
		document = docRepo.selectDocument(x);

		System.out.println("controller : document : " + document.getDocId());
		return document;
	}

	@RequestMapping("/getAll") // localhost:8080/document/getAll
	public List<Document> getDocuments() {

		List<Document> documentList;
		documentList = docRepo.selectDocuments();

		return documentList;
	}

// @PostMapping("/Add")//
// public void addCustomers(@RequestBody Customer customer)
// {
// cusRepo.insertCustomer(customer);
// }

	@PostMapping("/Add")
	public void addDocument(@RequestBody Document document) {
		docRepo.insertDocument(document);
	}

// @PutMapping("/update")//http://localhost:8080/cust/update
// public void updateCustomer(@RequestBody Customer customer)
// {
// cusRepo.updateCustomer(customer);
// }
//
// @DeleteMapping("/delete/{cust_id}")//http://localhost:8080/cust/delete/45
// public String deleteCustomer(@PathVariable("cust_id") int cust_id)
// {
// cusRepo.deleteCustomer(cust_id);
// return "delete successfully";
// }

}