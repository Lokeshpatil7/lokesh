package com.example.demo;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Application_Details;
import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Loan;
import com.example.demo.layer3.Application_DetailsRepoImp;


@SpringBootTest
public class Application_DetailsTests {

	@Autowired
	Application_DetailsRepoImp applicationRepo;
	
	@Test
	void insertApplicationTest()
	{
		Application_Details application=new Application_Details();
		
		
		application.setComments(" Documentation Done");
		application.setStatus("pending");
		application.setExpected_Amount(450000);
		application.setTenure(6);
		
		applicationRepo.insertApplication_Details(application);
		System.out.println("----------------------------------------------");

	}
	
	@Test
	void selectApplicationTest()
	{
		Application_Details application;
		application=applicationRepo.selectApplication_Details(50);
		System.out.println("Application no.  :"+application.getApplication_No());
		System.out.println("Comment  :"+application.getComments());
		System.out.println("Expecterd Ammount   :"+application.getExpected_Amount());
		System.out.println("Status  :"+application.getStatus());
		System.out.println("Tenure  :"+application.getTenure());
		System.out.println("----------------------------------------------");

	}
	
	
	@Test
	void selectAllApplicationTest()
	{
		List<Application_Details> applicationList;
		applicationList=applicationRepo.selectApplication_Details();
		for(Application_Details application :applicationList)
		{
			System.out.println("Application no.  :"+application.getApplication_No());
			System.out.println("Comments  :"+application.getComments());
			System.out.println("Expected_Amount  :"+application.getExpected_Amount());
			System.out.println("Status  :"+application.getStatus());
			System.out.println("Tenure  :"+application.getTenure());
			System.out.println("----------------------------------------------");
		}
	}
		
		
		@Test
		void updateApplicationTest()
		{
          Application_Details application = null;
         application =applicationRepo.find(Application_Details.class, 50);
	   	Assertions.assertNotNull(application);
	   	
		application.setComments("Done Document");
		application.setStatus("SuccesFul");
		application.setExpected_Amount(60000);
		application.setTenure(5);
		



		applicationRepo.updateApplication_Details(application);
		}	
		
		@Test
		void deleteApplicationTest()
		{
			Application_Details delete = null;
		delete = applicationRepo.find(Application_Details.class, 50);
		applicationRepo.deleteApplication_Details(50);
		}
	
	
	
}
	
	
	
	
	
	
	
	
	
	
	
