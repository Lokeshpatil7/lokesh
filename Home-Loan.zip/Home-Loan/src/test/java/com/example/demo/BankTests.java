package com.example.demo;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Application_Details;
import com.example.demo.layer2.Bank;
import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Loan;
import com.example.demo.layer3.BankRepositoryImpl;

@SpringBootTest
public class BankTests {


	@Autowired
	BankRepositoryImpl bankRepo;
	
	@Test
	void insertBankTest()
	{
		Bank bank=new Bank();
		bank.setB_Id(50);
		bank.setAccountNo(452923444);
		bank.setBankName("SBI BANK");
		bank.setIfscCode("SBINO03");
	
		bankRepo.insertBank(bank);
	}
	
	@Test
	void selectBankTest()
	{
		Bank bank;
		bank=bankRepo.selectBank(55);
		System.out.println("repo : bank "+bank);
		System.out.println("bankId :"+bank.getB_Id());
		System.out.println("bankName :"+bank.getBankName());
		System.out.println("Account No.:"+bank.getAccountNo());
		System.out.println("IFSC code :"+bank.getIfscCode());	
		System.out.println("----------------------------------------------");
}
	@Test
	void selectAllBankTest()
	{
		List<Bank> bankList;
		bankList=bankRepo.selectBanks();
		for(Bank bank :bankList)
		{
			System.out.println("bankId : "+bank.getB_Id());
			System.out.println("bankName : "+bank.getBankName());
			System.out.println("Account No.:"+bank.getAccountNo());
			System.out.println("IFSC code"+bank.getIfscCode());
			System.out.println("----------------------------------------------");
		}
		
	}
	
	@Test
	void updateLoanTest()
	{


	Bank bank = null;
	bank =bankRepo.find(Bank.class, 55);
	Assertions.assertNotNull(bank);

	bank.setAccountNo(6234567);
	bank.setBankName("Central Bank Of Indian");
	bank.setIfscCode("CBI156782234");

	bankRepo.updateBank(bank);
	}
	
	@Test
	void deleteBankTest()
	{
		Bank delete = null;
		delete = bankRepo.find(Bank.class,50);
		bankRepo.deleteBank(50);
	}
	

	
}
