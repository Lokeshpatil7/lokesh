package com.example.demo;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Bank;
import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Document;
import com.example.demo.layer2.Loan;
import com.example.demo.layer3.CustomerReposioryImpl;
import com.example.demo.layer3.DocumentRepositoryImpl;

@SpringBootTest
public class DocumentTest {
	@Autowired
	DocumentRepositoryImpl DocRepo;
	@Autowired
	CustomerReposioryImpl cusRepo;

	@Test
	void insertDocumentTest() {
		Customer customer = cusRepo.selectCustomer(33);
		Document document = new Document();

		document.setPanCard("pan Url");
		document.setVoterId("Voter url");
		document.setSalarySlip("salary slip");
		document.setLoa("2");
		document.setNocFromBuilder("noc form builder");
		document.setAgreementToSale("Agg. to sale");
		document.setCustomer(customer);
		DocRepo.insertDocument(document);

	}

	@Test
	void selectDocumentTest() {
		Document document;
		document = DocRepo.selectDocument(68);
		System.out.println("repo  : document" + document);
		System.out.println("document" + document.getDocId());
		System.out.println("document" + document.getPanCard());
		System.out.println("document" + document.getVoterId());
		System.out.println("document" + document.getSalarySlip());

		System.out.println("document" + document.getAgreementToSale());
		System.out.println("document" + document.getLoa());
		System.out.println("document" + document.getNocFromBuilder());

	}

	@Test
	void selectAllDocumentTest() {
		List<Document> doctList;
		doctList = DocRepo.selectDocuments();
		for (Document document : doctList) {
			System.out.println("document  :" + document.getDocId());
			System.out.println("document  :" + document.getPanCard());
			System.out.println("document  :" + document.getVoterId());
			System.out.println("document  :" + document.getSalarySlip());

			System.out.println("document   :" + document.getAgreementToSale());
			System.out.println("document   :" + document.getLoa());
			System.out.println("document   :" + document.getNocFromBuilder());

			System.out.println("---------------------------------------------");

		}

	}

	@Test
	void updateDocumentTest() {

		Document document = null;
		document = DocRepo.find(Document.class, 69);
		Assertions.assertNotNull(document);

		document.setPanCard("ghhjgjgh");
		document.setVoterId("hjghgjkhj");
		document.setSalarySlip("kjkhjh");
		document.setLoa("10");
		document.setNocFromBuilder("jhnjhjhki");
		document.setAgreementToSale("jkhkhki");

		DocRepo.updateDoument(document);
	}

	@Test
	void deleteDocumentTest() {
		Document delete = null;
		delete = DocRepo.find(Document.class, 74);

		DocRepo.deleteDocument(74);
	}

}