package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.ApplicationDetails;
import com.example.demo.layer2.Customer;
@Repository
public interface ApplicationDetailsRepo {
	void insertApplication_Details(ApplicationDetails Aobj);
	  
	ApplicationDetails selectApplication_Details(int application_No); //R
		List<ApplicationDetails> selectApplication_Details(); //RA
		
		void updateApplication_Details(ApplicationDetails Aobj); //U
		
		void deleteApplication_Details(int application_No); //D
}
