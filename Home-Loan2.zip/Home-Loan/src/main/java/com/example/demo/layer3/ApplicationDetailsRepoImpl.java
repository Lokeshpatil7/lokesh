package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.ApplicationDetails;
import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Tracker;

@Repository
public class ApplicationDetailsRepoImpl extends BaseRepository implements ApplicationDetailsRepo 
{

	@Transactional
	public void insertApplication_Details(ApplicationDetails Aobj) 
	{
		super.persist(Aobj);
		System.out.println("Application_Details insert");
		
	}

	@Override
	public ApplicationDetails selectApplication_Details(int application_No) 
	{
		System.out.println("Application_DetailsRepositoryImpl : selecting Application_Details  by application_No");
		ApplicationDetails application=super.find(ApplicationDetails.class,application_No);
		System.out.println("application_Details  :"+application.getApplication_No());
		System.out.println("application_Details  :"+application.getComments());
		System.out.println("application_Details  :"+application.getExpected_Amount());
		System.out.println("application_Details  :"+application.getStatus());
		System.out.println("application_Details  :"+application.getTenure());
		
		return application;
	}

	@Override
	public List<ApplicationDetails> selectApplication_Details() 
	{
	List<ApplicationDetails>  applicationList = new ArrayList<ApplicationDetails>();

	System.out.println("Application_DetailsRepositoryImpl : Selecting all Application_Details...");
	applicationList =  super.findAll("Application_Details");
	System.out.println("repo : applicationList ref  "+applicationList);
	System.out.println("repo : applicationList size "+applicationList.size());

	for(ApplicationDetails application : applicationList) {
		//System.out.println("repo: dept "+dept.getDepartmentNumber());
		System.out.println("application_Details  :"+application.getApplication_No());
		System.out.println("application_Details  :"+application.getComments());
		System.out.println("application_Details  :"+application.getExpected_Amount());
		System.out.println("application_Details  :"+application.getStatus());
		System.out.println("application_Details  :"+application.getTenure());	

	}
	
	return applicationList;
	}
	@Transactional
	public void updateApplication_Details(ApplicationDetails Aobj) 
	{
		super.merge(Aobj);
		System.out.println("Application Details Update.......");
	}

	@Transactional
	public void deleteApplication_Details(int application_No) 
	{
		super.remove(ApplicationDetails.class, application_No);
	}

}
