package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Document;

@Repository
public interface DocumentRepository
{
    void insertDocument(Document dobj);
    
	    Document selectDocument(int docId); //R
		List<Document> selectDocuments(); //RA
		
		void updateDocument(Document dobj); //U
		void deleteDocument(int docId); //D
}

