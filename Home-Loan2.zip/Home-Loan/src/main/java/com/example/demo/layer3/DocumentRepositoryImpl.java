 package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Document;


@Repository
public class DocumentRepositoryImpl extends BaseRepository implements DocumentRepository {

	@Transactional
	public void insertDocument(Document dobj) 
	{
		super.persist(dobj);
		System.out.println("Document Inserted");
				
	}

	@Override
	public Document selectDocument(int docId) {
		Document doc =super.find(Document.class, docId);
		return doc;
	}


	@Override
	public List<Document> selectDocuments() {
		List<Document> docList = new ArrayList<>();
		return super.findAll("Document");
	}
	

	 @Transactional
	public void updateDocument(Document dobj) {
		super.merge(dobj);
		
	}


	 @Transactional
	public void deleteDocument(int docId) {
		super.remove(Customer.class, docId);
		
	}
		 
	 }
	 
	 



