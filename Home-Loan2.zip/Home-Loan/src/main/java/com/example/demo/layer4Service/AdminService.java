package com.example.demo.layer4Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Admin;

@Service
public interface AdminService {
	List<Admin> getAllAdminService();
	List<Admin> getAllAdminFromDatabaseService();
	void addAdminService(Admin theAdmin);
}
