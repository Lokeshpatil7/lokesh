package com.example.demo.layer4Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.ApplicationDetails;



@Service
public interface ApplicationDetailsService {
	List<ApplicationDetails> getAllApplicationDetailsService();
	List<ApplicationDetails> getAllApplicationDetailsFromDatabaseService();
	void addApplicationDetailsService(ApplicationDetails theApplicationDetails);
}
