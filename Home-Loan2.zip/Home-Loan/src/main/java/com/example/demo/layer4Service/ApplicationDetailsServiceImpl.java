package com.example.demo.layer4Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Customer;

@Service
public class ApplicationDetailsServiceImpl implements CustomerService {

	@Override
	public List<Customer> getAllCustomerService() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> getAllCustomerFromDatabaseService() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addCustomerService(Customer theCustomer) {
		// TODO Auto-generated method stub
		
	}

}
