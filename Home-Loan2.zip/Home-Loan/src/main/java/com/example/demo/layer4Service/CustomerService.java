package com.example.demo.layer4Service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.example.demo.layer2.Customer;



@Service
public interface CustomerService {
	List<Customer> getAllCustomerService();
	List<Customer> getAllCustomerFromDatabaseService();
	void addCustomerService(Customer theCustomer);
}
