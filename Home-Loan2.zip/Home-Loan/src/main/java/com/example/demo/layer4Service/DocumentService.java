package com.example.demo.layer4Service;

import org.springframework.stereotype.Service;

@Service
public interface DocumentService {

}
