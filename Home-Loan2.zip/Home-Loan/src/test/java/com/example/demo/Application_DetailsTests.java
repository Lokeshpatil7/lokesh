package com.example.demo;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.ApplicationDetails;
import com.example.demo.layer2.Bank;
import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Loan;
import com.example.demo.layer3.ApplicationDetailsRepoImpl;


@SpringBootTest
public class Application_DetailsTests {

	@Autowired
	ApplicationDetailsRepoImpl applicationRepo;
	
	@Test
	void insertApplicationTest()
	{
		ApplicationDetails application=new ApplicationDetails();
		
		
		application.setComments("Done Document");
		application.setStatus("pending");
		application.setExpected_Amount(50000);
		application.setTenure(5);
		applicationRepo.insertApplication_Details(application);
	}
	
	@Test
	void selectApplicationTest()
	{
		ApplicationDetails application;
		application=applicationRepo.selectApplication_Details(50);
		System.out.println("application_Details  :"+application.getApplication_No());
		System.out.println("application_Details  :"+application.getComments());
		System.out.println("application_Details  :"+application.getExpected_Amount());
		System.out.println("application_Details  :"+application.getStatus());
		System.out.println("application_Details  :"+application.getTenure());
	}
	
	
	@Test
	void selectAllApplicationTest()
	{
		List<ApplicationDetails> applicationList;
		applicationList=applicationRepo.selectApplication_Details();
		for(ApplicationDetails application :applicationList)
		{
			System.out.println("application_Details  :"+application.getApplication_No());
			System.out.println("application_Details  :"+application.getComments());
			System.out.println("application_Details  :"+application.getExpected_Amount());
			System.out.println("application_Details  :"+application.getStatus());
			System.out.println("application_Details  :"+application.getTenure());
			
		}
	}
		
		
		@Test
		void updateApplicationTest()
		{
          ApplicationDetails application = null;
         application =applicationRepo.find(ApplicationDetails.class, 50);
	   	Assertions.assertNotNull(application);
	   	
		application.setComments("Done Document");
		application.setStatus("SuccesFul");
		application.setExpected_Amount(60000);
		application.setTenure(5);

		applicationRepo.updateApplication_Details(application);
		}	
		
		@Test
		void deleteApplicationTest()
		{
			ApplicationDetails delete = null;
			delete = applicationRepo.find(ApplicationDetails.class, 31 );
			applicationRepo.deleteApplication_Details(31);
			
		}

		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

