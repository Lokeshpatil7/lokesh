package com.example.demo;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Bank;
import com.example.demo.layer2.Customer;

import com.example.demo.layer2.Property;
import com.example.demo.layer3.CustomerReposioryImpl;
import com.example.demo.layer3.PropertyRepositoryImpl;

@SpringBootTest
class CustomerTests {
	@Autowired
	CustomerReposioryImpl cusRepo;
	
	@Test
	void insertCustomerTest()
	{
		Customer Cus=new  Customer();
		
		Cus.setFirstName("Lokesh");
		Cus.setMiddleName("P");
		Cus.setLastName("Patil");
		Cus.setEmail("lokesh4797@gmail.com");
		Cus.setPassword("lokesh@1234");
		Cus.setPhoneNo("8459950303");         //long to string
		Cus.setDob(LocalDate.of(2098, 11, 25));
		Cus.setNationality("Indian");
		Cus.setAdhaarNo("1234542232");
		Cus.setPanCard("Lod223t8");
		cusRepo.insertCustomer(Cus);
		
}

	@Test
	void selectCustomerTest()
	{
		Customer cus;
		cus=cusRepo.selectCustomer(26);
		System.out.println("repo : cus "+cus);
		System.out.println("cus"+cus.getCust_Id());
		System.out.println("cus "+cus.getFirstName());
		System.out.println("cus "+cus.getMiddleName());
		System.out.println("cus "+cus.getLastName());
		System.out.println("cus "+cus.getAdhaarNo());
		System.out.println("cus "+cus.getEmail());
		System.out.println("cus "+cus.getNationality());
		System.out.println("cus "+cus.getPanCard());
	
}
	
	@Test
	void selectAllCustomersTest()
	{
		List<Customer> custList;
		custList=cusRepo.selectCustomers();
		for(Customer cus :custList)
		{
			System.out.println("cus"+cus.getCust_Id());
			System.out.println("cus "+cus.getFirstName());
			System.out.println("cus "+cus.getMiddleName());
			System.out.println("cus "+cus.getLastName());
			System.out.println("cus "+cus.getAdhaarNo());
			System.out.println("cus "+cus.getEmail());
			System.out.println("cus "+cus.getNationality());
			System.out.println("cus "+cus.getPanCard());
		
			
		}

		
	}
	@Test
	void updateCuststomerTest()
	{
	Customer cust = null;
	cust =cusRepo.find(Customer.class, 27);
	Assertions.assertNotNull(cust);

	cust.setFirstName("Lokesh");
	cust.setMiddleName("Pravin");
	cust.setLastName("Patil");
	cust.setEmail("ritesh@gmail.com");
	cust.setPassword("lokesh@1234");
	cust.setPhoneNo("8459950303");
	cust.setDob(LocalDate.of(1998, 10, 07));
	cust.setNationality("Indian");
	cust.setAdhaarNo("111222333444");         //string
	cust.setPanCard("PL22389KM");

	cusRepo.updateCustomer(cust);
	}
	
	
	@Test
	void deleteCustomerTest()
	{
		Customer delete = null;
		delete = cusRepo.find(Customer.class, 34);
		cusRepo.deleteCustomer(34);
	}
	
//	@Test
//	void deleteBankTest()
//	{
//		Bank delete = null;
//		delete = bankRepo.find(Bank.class,50);
//		bankRepo.deleteBank(50);
//	}
	

}
