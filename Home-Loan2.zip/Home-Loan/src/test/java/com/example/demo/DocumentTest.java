package com.example.demo;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Document;
import com.example.demo.layer3.CustomerReposioryImpl;
import com.example.demo.layer3.DocumentRepositoryImpl;

@SpringBootTest
public class DocumentTest 
{
 @Autowired
 DocumentRepositoryImpl DocRepo;
 
 @Test
	void insertDocumentTest()
	{
		Document doc=new  Document();  //url 
		
		doc.setPanCard("pan url");
		doc.setVoterId("voterid url");
		doc.setSalarySlip("salary slip url");
		doc.setLoa("loa url");
		doc.setAgreementToSale("agreement url");
		doc.setNocFromBuilder("noc url");
		
		DocRepo.insertDocument(doc);
		
}
 
 @Test
	void selectDocumentTest()
	{
		Document doc;
		doc=DocRepo.selectDocument(26);
		
		System.out.println("repo : Document "+doc);
		System.out.println(""+doc.getDocId());
		
		
}
 
 
 
 
 
 
 
 
 
	@Test
	void deleteDocumentsTest()
	{
		Document delete = null;
		delete = DocRepo.find(Document.class,50);
		DocRepo.deleteDocument(50);
	}
    
 
//	@Test
//	void deleteBankTest()
//	{
//		Bank delete = null;
//		delete = bankRepo.find(Bank.class,50);
//		bankRepo.deleteBank(50);
//	}
}
