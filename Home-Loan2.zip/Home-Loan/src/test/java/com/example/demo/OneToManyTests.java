package com.example.demo;

import org.junit.jupiter.api.Test;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Document;

public class OneToManyTests 
{
//	 @Test
//		void insertDocument()
//		{
//		 Customer customer =custRepo.selectCustomer(33);
//			Document doc=new Document();
//			{
//				doc.setPanCard("Ram1234cu");
//				doc.setVoterId("hjkkfj68574");
//				doc.setLoa(1627384);
//				doc.setNocFromBuilder("hjwdjhjkhjkhjkh");
//				doc.setSalarySlip("yes");
//				doc.setAgreementToSale("Yes");
//				doc.setCustomer(customer);
//				
//				DocRepo.insertDocument(doc);
//				
//			}
//		}
//	

}
