package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="")
public class ApplicationDetails {
	
	//Application pojo's
	@Id
    @Column(name="")
	private int applicationNo;
	
    @Column(name="")
	private String comments;
    @Column(name="")
	private String status;
    @Column(name="")
	private double expectedAmmount;
    @Column(name="")
	private String tenure;
    
    @OneToOne
    private Customer customer;
    
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public int getApplicationNo() {
		return applicationNo;
	}
	public void setApplicationNo(int applicationNo) {
		this.applicationNo = applicationNo;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getExpectedAmmount() {
		return expectedAmmount;
	}
	public void setExpectedAmmount(double expectedAmmount) {
		this.expectedAmmount = expectedAmmount;
	}
	public String getTenure() {
		return tenure;
	}
	public void setTenure(String tenure) {
		this.tenure = tenure;
	}
	

	
}
