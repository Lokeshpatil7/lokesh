package com.example.demo.layer2;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="CustomerTable")
public class Customer {
	
    //customer table pojo's
	
	@Id
	@Column(name="")
	private int custId;
	
	@Column(name="")
	private String firstName;
	
	@Column(name="")
	private String middletName;
	
	@Column(name="")
	private String lastName;
	
	@Column(name="")
	private String email;
	
	@Column(name="")
	private String password;
	
	@Column(name="")
	private String   phoneNo;
	
	@Column(name="")
	private LocalDate dob;
	
	@Column(name="")
	private String nationality;
	
	@Column(name="")
	private String   adhaarNo;
	
	@Column(name="")
	private String panNo;
	
	@Column(name="")
	private String propertyId;
	
	@Column(name="")
	private String loanId;
	
	@Column(name="")
	private String docId;
	
	
	@OneToOne
	private PropertyAndIncome propertyandincome; //fk
	
	@OneToOne
	private ApplicationDetails applicationdetails;
	
	
	@OneToOne
	private Loan loan; //fk

	@OneToOne
	private Bank  bank; 
	
	
	public ApplicationDetails getApplicationdetails() {
		return applicationdetails;
	}
	public void setApplicationdetails(ApplicationDetails applicationdetails) {
		this.applicationdetails = applicationdetails;
	}
	
	public Bank getBank() {
		return bank;
	}
	public void setBank(Bank bank) {
		this.bank = bank;
	}
	public PropertyAndIncome getPropertyandincome() {
		return propertyandincome;
	}
	public void setPropertyandincome(PropertyAndIncome propertyandincome) {
		this.propertyandincome = propertyandincome;
	}
	public Loan getLoan() {
		return loan;
	}
	public void setLoan(Loan loan) {
		this.loan = loan;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int appId) {
		this.custId = appId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddletName() {
		return middletName;
	}
	public void setMiddletName(String middletName) {
		this.middletName = middletName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getAdhaarNo() {
		return adhaarNo;
	}
	public void setAdhaarNo(String adhaarNo) {
		this.adhaarNo = adhaarNo;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}
	public String getLoanId() {
		return loanId;
	}
	public void setLoanId(String loanId) {
		this.loanId = loanId;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	

}
