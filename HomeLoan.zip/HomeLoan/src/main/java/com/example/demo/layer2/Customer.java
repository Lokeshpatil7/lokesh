package com.example.demo.layer2;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="")
public class Customer {
	
    //customer table pojo's
	
	@Id
	@Column(name="")
	private int appId;
	
	@Column(name="")
	private String firstName;
	
	@Column(name="")
	private String middletName;
	
	@Column(name="")
	private String lastName;
	
	@Column(name="")
	private String email;
	
	@Column(name="")
	private String password;
	
	@Column(name="")
	private long   phoneNo;
	
	@Column(name="")
	private LocalDate dob;
	
	@Column(name="")
	private String nationality;
	
	@Column(name="")
	private long   adhaarNo;
	
	@Column(name="")
	private String panNo;
	
	@Column(name="")
	private String propertyId;
	
	@Column(name="")
	private String loanId;
	
	@Column(name="")
	private String docId;
	
	@OneToOne
	private PropertyAndIncome propertyandincome;
	
//	@OneToOne
//	private Loan loan; 
	
	public PropertyAndIncome getPropertyandincome() {
		return propertyandincome;
	}
	public void setPropertyandincome(PropertyAndIncome propertyandincome) {
		this.propertyandincome = propertyandincome;
	}
//	public Loan getLoan() {
//		return loan;
//	}
//	public void setLoan(Loan loan) {
//		this.loan = loan;
//	}
	public int getAppId() {
		return appId;
	}
	public void setAppId(int appId) {
		this.appId = appId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddletName() {
		return middletName;
	}
	public void setMiddletName(String middletName) {
		this.middletName = middletName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public long getAdhaarNo() {
		return adhaarNo;
	}
	public void setAdhaarNo(long adhaarNo) {
		this.adhaarNo = adhaarNo;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}
	public String getLoanId() {
		return loanId;
	}
	public void setLoanId(String loanId) {
		this.loanId = loanId;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	

}
