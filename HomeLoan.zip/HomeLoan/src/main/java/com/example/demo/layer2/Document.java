package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="")
public class Document {
	
	
	//document pojo
	
	@Id
	@Column(name="")
	private String docId;
	@Column(name="")
	private String panNo;
	@Column(name="")
	private String voterId;
	@Column(name="")
	private String salarySlip;
	@Column(name="")
	private String LOA;
	@Column(name="")
	private String NOCfromBuilder;
	@Column(name="")
	private String agreementToSale;
	@Column(name="")
	private int appId;
	
	
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getVoterId() {
		return voterId;
	}
	public void setVoterId(String voterId) {
		this.voterId = voterId;
	}
	public String getSalarySlip() {
		return salarySlip;
	}
	public void setSalarySlip(String salarySlip) {
		this.salarySlip = salarySlip;
	}
	public String getLOA() {
		return LOA;
	}
	public void setLOA(String lOA) {
		LOA = lOA;
	}
	public String getNOCfromBuilder() {
		return NOCfromBuilder;
	}
	public void setNOCfromBuilder(String nOCfromBuilder) {
		NOCfromBuilder = nOCfromBuilder;
	}
	public String getAgreementToSale() {
		return agreementToSale;
	}
	public void setAgreementToSale(String agreementToSale) {
		this.agreementToSale = agreementToSale;
	}
	public int getAppId() {
		return appId;
	}
	public void setAppId(int appId) {
		this.appId = appId;
	}
	

	
}
