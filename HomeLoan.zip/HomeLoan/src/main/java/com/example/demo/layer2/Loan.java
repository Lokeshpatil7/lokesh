package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="LoanTable")
public class Loan {
     
	//loan pojo
	@Id   //pk
	@Column(name="")
	private String loanId;
	@Column(name="")
	private String maxLoanGrant;
	@Column(name="")
	private String tenure;
	@Column(name="")
	private double loanAmount;
	@Column(name="")
	private String ROI;
	@Column(name="")
	private double EMI;
	
	
	@OneToOne
	private Customer customer; 
	
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public String getLoanId() {
		return loanId;
	}
	public void setLoanId(String loanId) {
		this.loanId = loanId;
	}
	public String getMaxLoanGrant() {
		return maxLoanGrant;
	}
	public void setMaxLoanGrant(String maxLoanGrant) {
		this.maxLoanGrant = maxLoanGrant;
	}
	public String getTenure() {
		return tenure;
	}
	public void setTenure(String tenure) {
		this.tenure = tenure;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public String getROI() {
		return ROI;
	}
	public void setROI(String rOI) {
		ROI = rOI;
	}
	public double getEMI() {
		return EMI;
	}
	public void setEMI(double eMI) {
		EMI = eMI;
	}
	


}
