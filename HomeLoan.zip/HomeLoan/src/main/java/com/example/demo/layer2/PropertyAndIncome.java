package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="PropertyAndIncome")
public class PropertyAndIncome {

	
	//property and income pojo's
	
	@Id
	@Column(name="")
	private String propertyId;
	@Column(name="")
	private String propertyLoc;
	@Column(name="")
	private String propertyName;
	@Column(name="")
	private double estimateAmt;
	@Column(name="")
	private String typeOfEmp;
	@Column(name="")
	private int retAge;
	@Column(name="")
	private String orgType;
	@Column(name="")
	private String employerName;
	@Column(name="")
	private double income;
	
	@OneToOne
	private Customer customer;
	
	
	public String getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}
	public String getPropertyLoc() {
		return propertyLoc;
	}
	public void setPropertyLoc(String propertyLoc) {
		this.propertyLoc = propertyLoc;
	}
	public String getPropertyName() {
		return propertyName;
	}
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	public double getEstimateAmt() {
		return estimateAmt;
	}
	public void setEstimateAmt(double estimateAmt) {
		this.estimateAmt = estimateAmt;
	}
	public String getTypeOfEmp() {
		return typeOfEmp;
	}
	public void setTypeOfEmp(String typeOfEmp) {
		this.typeOfEmp = typeOfEmp;
	}
	public int getRetAge() {
		return retAge;
	}
	public void setRetAge(int retAge) {
		this.retAge = retAge;
	}
	public String getOrgType() {
		return orgType;
	}
	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}
	public String getEmployerName() {
		return employerName;
	}
	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}
	public double getIncome() {
		return income;
	}
	public void setIncome(double income) {
		this.income = income;
	}





}
