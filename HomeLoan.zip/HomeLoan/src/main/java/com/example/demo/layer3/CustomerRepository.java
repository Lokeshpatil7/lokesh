package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Customer;



@Repository
public interface CustomerRepository {

    void insertCustomer(Customer cust); //C
	
    Customer selectCustomer(int custId); //R
	List<Customer> selectAllCustomers(); //RA
	
	void updateCustomer(Customer custId); //U
	
	void deleteCustomer(int custId); //D
	
}

