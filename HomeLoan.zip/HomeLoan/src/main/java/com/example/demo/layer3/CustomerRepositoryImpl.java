package com.example.demo.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Customer;


	@Repository
	public class CustomerRepositoryImpl extends BaseRepository implements CustomerRepository {

		
		public CustomerRepositoryImpl() {
				System.out.println("CustomerRepositoryImpl ..");	
		}
		
		@Transactional
		public void insertCustomer(Customer dobj) {
			  
			super.persist(dobj); // invoking the dummy persist of the super class
			System.out.println("Customer inserted...");
		}

		@Override
		public Customer selectCustomer(int dno) {
			// TODO Auto-generated method stub
			System.out.println("CustomerRepositoryImpl : selecting Customer by custId");
			Customer dept = super.find(Customer.class, dno);
			
			return dept;
		}

		@Override
		public List<Customer> selectCustomers() {
			List<Customer>  custList = new ArrayList<Customer>();
		
				System.out.println("CustomerRepositoryImpl : Selecting all Customers...");
				return super.findAll("Customer");
			
		}

		@Transactional
		public void updateCustomer(Customer dobj) {
			// TODO Auto-generated method stub
			System.out.println("CustomerRepositoryImpl : Updating Customer..");
			super.merge(dobj);
		}

		@Transactional
		public void deleteCustomer(int dno) {
			// TODO Auto-generated method stub
			System.out.println("CustomerRepositoryImpl : Deleting Customer");
			super.remove(Customer.class, dno);
		}

		@Override
		public List<Customer> selectAllCustomers() {
			// TODO Auto-generated method stub
			return null;
		}

		

	}