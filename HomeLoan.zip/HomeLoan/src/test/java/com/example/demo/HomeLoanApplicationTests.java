package com.example.demo;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Bank;
import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Loan;
import com.example.demo.layer2.PropertyAndIncome;

@SpringBootTest
class HomeLoanApplicationTests {

	// Property and Income
	@Test
	public void insertPersonPropertAndIncome() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA"); // persistence.xml
																										// is read here

		System.out.println("Entity Manager Factory : " + entityManagerFactory);

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		// ctrl+shift+M

		System.out.println("Entity Manager : " + entityManager);

		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();

		PropertyAndIncome prop = new PropertyAndIncome();

		// new/blank entity object
		prop.setPropertyId("PO545");
		prop.setPropertyLoc("Bhusawal");
		prop.setPropertyName("Flat ");
		prop.setEstimateAmt(7550000);
		prop.setTypeOfEmp("business");
		prop.setRetAge(58);
		prop.setOrgType("Food centre ");
		prop.setEmployerName("Virat Singh");
		prop.setIncome(50000);

		entityManager.persist(prop); // generate the insert query for us
		transaction.commit();
	}

	// Loan
	@Test
	public void insertLoan() {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA"); // persistence.xml
																										// is read here

		System.out.println("Entity Manager Factory : " + entityManagerFactory);

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		// ctrl+shift+M

		System.out.println("Entity Manager : " + entityManager);

		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
 
		Loan loan = new Loan();

		// new/blank entity object

		loan.setLoanId("3");
		loan.setMaxLoanGrant("2500000");
		loan.setTenure("1.5years");
		loan.setLoanAmount(500000);
		loan.setROI("2");
		loan.setEMI(50000);

		entityManager.persist(loan); // generate the insert query for us
		transaction.commit();
	}

	// Bank
	@Test
	public void insertBank() {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA"); // persistence.xml
																										// is read here

		System.out.println("Entity Manager Factory : " + entityManagerFactory);

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		// ctrl+shift+M

		System.out.println("Entity Manager : " + entityManager);

		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();

		Bank bank = new Bank();

		// new/blank entity object
		bank.setBankName("Maharashtra bank");
		bank.setAccountNo(55666884);
		bank.setIFSCcode("MH0002");
		bank.setBankId(22);

		entityManager.persist(bank); // generate the insert query for us
		transaction.commit();
	}

	// Customer
		@Test
		public void insertCustomer() {

			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA"); // persistence.xml
																											// is read here

			System.out.println("Entity Manager Factory : " + entityManagerFactory); // EMF create multiple times

			EntityManager entityManager = entityManagerFactory.createEntityManager();
	    //ctrl+shift+M

			System.out.println("Entity Manager : " + entityManager);

			EntityTransaction transaction = entityManager.getTransaction();
			transaction.begin();

			Customer cust = new Customer();

	     //new/blank entity object
			cust.setCustId(3);
			cust.setFirstName("Amar");
			cust.setMiddletName("p");
			cust.setLastName("Thakur");
			cust.setEmail("Amr123@gmail.com");
			cust.setPassword("Amar@123");
			cust.setPhoneNo("944554311");
			cust.setDob(LocalDate.of(1999, 11, 25));
			cust.setNationality("Indian");
			cust.setAdhaarNo("222488444");
			cust.setPanNo("dfdgg458");
	  //	cust.setPropertyId("hjhrthj356");
	  //	cust.setLoanId("1");
	  //	cust.setDocId("DFG45");

			entityManager.persist(cust); // generate the insert query for us
			transaction.commit();
		}

//	@Test
//	void assignExistingCustomerToExistingLoan()
//	{
//	EntityManagerFactory entityManagerFactory =
//	Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here
//
//	System.out.println("Entity Manager Factory : "+entityManagerFactory);
//
//	EntityManager entityManager = entityManagerFactory.createEntityManager();
//	//ctrl+shift+M
//
//	System.out.println("Entity Manager : "+entityManager);
//
//	EntityTransaction transaction = entityManager.getTransaction();
//	transaction.begin();
//
//
//	Customer customer  = entityManager.find(Customer.class, 2);
//	Loan loan = entityManager.find(Loan.class, 4);
//
//	customer.setLoan(loan);// are we setting the FK?
//	loan.setCustomer(customer); // are we setting the FK?
//
//	entityManager.merge(customer);
//	entityManager.merge(loan);
//
//	transaction.commit();
//
//	}

	
}
