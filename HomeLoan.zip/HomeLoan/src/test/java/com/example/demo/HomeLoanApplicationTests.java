package com.example.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.PropertyAndIncome;


@SpringBootTest
class HomeLoanApplicationTests {


	@Test
	public void insertPerson() {
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		
			PropertyAndIncome prop= new PropertyAndIncome();
			
			
			//new/blank entity object
			prop.setPropertyId("HX545");
			prop.setPropertyLoc("Pune,Ravet");
			prop.setPropertyName("1Bhk falt");
			prop.setEstimateAmt(3550000);
			prop.setTypeOfEmp("Developer");
			prop.setRetAge(58);
			prop.setOrgType("IT industry");
			prop.setEmployerName("Avinash Ugale");
			prop.setIncome(50000);
			
			
			entityManager.persist(prop); //generate the insert query for us 
		transaction.commit();
	}
	

}
