 package com.java.layer2;

  //for dept table
public class Department { 
	
	private int departmentNumber ;       //pojo
	private String departmentName ;      //pojo
	private String departmentLocation ;  //pojo
	  
	
	//getter/setter method -through source
	public int getDepartmentNumber() {
		return departmentNumber;
	}
	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getDepartmentLocation() {
		return departmentLocation;
	}
	public void setDepartmentLocation(String departmentLocation) {
		this.departmentLocation = departmentLocation;
	}
	

}
