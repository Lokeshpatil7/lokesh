package com.java.layer4;

import java.util.List;

import com.java.layer2.Department;
import com.java.layer3.DepartmentDAOImpl;


public class DepartmentServiceImpl implements DepartmentService {
	
	 DepartmentDAOImpl deptDao = new  DepartmentDAOImpl();

	@Override
	public void createDepatmentService(Department dobj) {
		// TODO Auto-generated method stub
		deptDao.insertDepartment (dobj);
    System.out.println("DepatmentServiceImpl createDepartment" );
    
    }

	@Override
	public List<Department> findAllDeptService() {
		// TODO Auto-generated method stub
		return deptDao.selectDepartments();
	}
   
}
