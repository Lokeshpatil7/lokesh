package com.java.layer5;

import com.java.layer2.Department;
import com.java.layer4.DepartmentServiceImpl;

public class DepartmentController {
	public static void main(String[] args) {
		DepartmentServiceImpl deptService = new DepartmentServiceImpl();
				
		Department deptObj = new Department	();
		deptObj.setDepartmentNumber(55);
		deptObj.setDepartmentName("Manager");
		deptObj.setDepartmentLocation("pune");
		
		deptService.createDepatmentService(deptObj);
	}

}
