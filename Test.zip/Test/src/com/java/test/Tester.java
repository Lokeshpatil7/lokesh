package com.java.test;

import com.java.bank.SavingsAccount;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;



public class Tester {
  
	@Test
	public void testA() {
		System.out.println("a Testing2 savings account..");
		SavingsAccount saObj = Bank.getAccount("sav");
		Assertions.assertTrue(saObj !=null);
		System.out.println("Test passed1...");
		
		System.out.println("Object created...");
		saObj.withdraw(4000);
		Assertions.assertEquals(1000,saObj.getAccountBalance());
		System.out.println("Test2 passed2...");
	}
}
